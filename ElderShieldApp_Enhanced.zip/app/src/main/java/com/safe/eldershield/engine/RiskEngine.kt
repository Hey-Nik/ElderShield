package com.safe.eldershield.engine

import android.content.Context
import android.content.Intent
import com.safe.eldershield.ui.ElderOverlayActivity
import kotlin.math.min

object RiskEngine {
    private val scamKeywords = listOf(
        "kyc", "suspended", "reactivate", "income tax", "refund", "urgent",
        "customs", "parcel", "upi", "collect request", "otp", "verify account",
        "loan", "sebi", "investment", "demat", "blocked", "legal action",
        "prize", "lottery", "job offer", "limited time", "click here"
    )

    fun onWhatsAppEvent(ctx: Context, title: String, body: String) {
        val isIncomingCall = body.contains("Incoming voice call", ignoreCase = true) ||
                body.contains("Incoming video call", ignoreCase = true)
        if (isIncomingCall) {
            val caller = title.ifBlank { "Unknown" }
            val risk = scoreIncomingCall(ctx, caller, "whatsapp")
            if (risk >= 0.55) {
                val i = Intent(ctx, ElderOverlayActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("caller", caller)
                }
                ctx.startActivity(i)
            }
        }
    }

    fun scoreIncomingCall(ctx: Context, caller: String, source: String): Double {
        var score = 0.0
        if (caller.startsWith("+") && !caller.startsWith("+91")) score += 0.2
        if (caller.length >= 10) score += 0.2
        if (source == "whatsapp") score += 0.15
        return min(1.0, score)
    }

    fun scoreMessage(body: String, urls: List<String>): Double {
        val text = body.lowercase()
        var score = 0.0
        val hits = scamKeywords.count { text.contains(it) }
        score += (hits * 0.1).coerceAtMost(0.4)

        if (urls.isNotEmpty()) {
            val uScore = urls.map { UrlUtils.scoreUrl(it) }.maxOrNull() ?: 0.0
            score += uScore * 0.5
        }

        if (text.contains("otp") || text.contains("upi pin")) score += 0.1

        return score.coerceAtMost(1.0)
    }
}