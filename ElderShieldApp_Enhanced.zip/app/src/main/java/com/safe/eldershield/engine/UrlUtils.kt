package com.safe.eldershield.engine

import java.util.regex.Pattern
import java.net.IDN

object UrlUtils {
    private val urlPattern: Pattern = Pattern.compile(
        "(https?://[\w\-\.\u00a1-\uffff/%?#=&;:+,~]+)",
        Pattern.CASE_INSENSITIVE
    )

    private val shorteners = setOf("bit.ly","tinyurl.com","t.co","is.gd","cutt.ly","buff.ly","rb.gy","ow.ly")

    fun extractUrls(text: String): List<String> {
        val m = urlPattern.matcher(text)
        val out = mutableListOf<String>()
        while (m.find()) {
            out.add(m.group(1))
        }
        return out
    }

    fun scoreUrl(raw: String): Double {
        // Basic lexical checks only (no network calls)
        return try {
            val host = raw.substringAfter("://").substringBefore("/").lowercase()
            val puny = IDN.toASCII(host)
            var score = 0.0
            if (host.count { it == '.' } >= 2) score += 0.1
            if (host.any { it.isDigit() }) score += 0.1
            if (host.length > 20) score += 0.1
            if (shorteners.any { host.contains(it) }) score += 0.3
            if (!raw.startsWith("https://")) score += 0.2
            if (hasConfusables(host)) score += 0.2
            score.coerceAtMost(1.0)
        } catch (e: Exception) {
            0.0
        }
    }

    private fun hasConfusables(host: String): Boolean {
        // crude check: non-ascii characters in host
        return host.any { it.code > 127 }
    }
}