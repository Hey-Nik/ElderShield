package com.safe.eldershield.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ElderAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Optional: monitor WA call UI state if needed for overlays
    }
    override fun onInterrupt() { }
}