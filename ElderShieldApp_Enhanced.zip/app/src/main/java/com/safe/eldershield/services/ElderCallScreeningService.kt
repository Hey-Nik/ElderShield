package com.safe.eldershield.services

import android.telecom.Call
import android.telecom.CallScreeningService
import com.safe.eldershield.engine.RiskEngine

class ElderCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart ?: "unknown"
        val risk = RiskEngine.scoreIncomingCall(applicationContext, number, "phone")
        val response = CallResponse.Builder()
        if (risk >= 0.8) {
            response.setDisallowCall(true).setRejectCall(true).setSkipCallLog(false).setSkipNotification(true)
        } else if (risk >= 0.55) {
            response.setSilenceCall(true)
        }
        respondToCall(callDetails, response.build())
    }
}