package com.safe.eldershield.services

import android.app.Notification
import android.content.Intent
import android.net.Uri
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.safe.eldershield.engine.RiskEngine
import com.safe.eldershield.engine.UrlUtils
import com.safe.eldershield.ui.SafeWebActivity

class UnifiedNotifListener : NotificationListenerService() {
    private val whatsapp = "com.whatsapp"
    private val smsApps = setOf(
        "com.google.android.apps.messaging", // Google Messages
        "com.samsung.android.messaging",
        "com.truecaller"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text  = (extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "")
        val big   = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: "")
        val body = listOf(title, text, big).joinToString(" ")

        if (pkg == whatsapp) {
            RiskEngine.onWhatsAppEvent(applicationContext, title, body)
        }

        if (pkg in smsApps || pkg == whatsapp) {
            // Scam message/link detection
            val urls = UrlUtils.extractUrls(body)
            val score = RiskEngine.scoreMessage(body, urls)
            if (score >= 0.8 && urls.isNotEmpty()) {
                // Open in SafeWeb (first URL) – or you can show a notification to tap
                val i = Intent(applicationContext, SafeWebActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra("url", urls.first())
                }
                startActivity(i)
            } else if (score >= 0.55 && urls.isNotEmpty()) {
                // Optionally, we could raise a heads-up or overlay; for now just safe-open
                val i = Intent(applicationContext, SafeWebActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra("url", urls.first())
                }
                startActivity(i)
            }
        }
    }
}