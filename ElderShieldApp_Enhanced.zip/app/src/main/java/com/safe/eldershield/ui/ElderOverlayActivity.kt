package com.safe.eldershield.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.safe.eldershield.R
import com.safe.eldershield.util.Prefs

class ElderOverlayActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_overlay)

        val caller = intent.getStringExtra("caller") ?: "Unknown"
        findViewById<TextView>(R.id.tvTitle).text = "Unknown Caller: $caller"

        findViewById<Button>(R.id.btnSecret).setOnClickListener {
            val secret = Prefs.getSecret(this)
            val phone = caller.filter { it.isDigit() }
            val uri = Uri.parse("https://wa.me/$phone?text=" + Uri.encode("What is our family code? ($secret)"))
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
        findViewById<Button>(R.id.btnAllow).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnBlock).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnCallFamily).setOnClickListener {
            val num = Prefs.getCaregiverNumber(this)
            if (num.isNotEmpty()) {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
            }
        }
    }
}