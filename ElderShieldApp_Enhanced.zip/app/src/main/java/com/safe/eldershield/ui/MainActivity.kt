package com.safe.eldershield.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.safe.eldershield.R
import com.safe.eldershield.util.Prefs

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnGrantNotif).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val et = findViewById<EditText>(R.id.etSecret)
        et.setText(Prefs.getSecret(this))
        findViewById<Button>(R.id.btnSaveSecret).setOnClickListener {
            Prefs.setSecret(this, et.text.toString())
        }
        val cg = findViewById<EditText>(R.id.etCaregiver)
        cg.setText(Prefs.getCaregiverNumber(this))
        findViewById<Button>(R.id.btnSaveCaregiver).setOnClickListener {
            Prefs.setCaregiverNumber(this, cg.text.toString())
        }
    }
}