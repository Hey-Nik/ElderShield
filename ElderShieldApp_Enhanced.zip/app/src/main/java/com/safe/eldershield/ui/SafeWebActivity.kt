package com.safe.eldershield.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.safe.eldershield.R

class SafeWebActivity : AppCompatActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_safeweb)
        val wv = findViewById<WebView>(R.id.web)

        val url = intent?.dataString ?: intent?.getStringExtra("url") ?: "about:blank"

        // Hardened WebView
        val s: WebSettings = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = false
        s.setSupportZoom(false)
        s.savePassword = false
        s.saveFormData = false
        s.userAgentString = s.userAgentString + " ElderShieldSafe/1.0"
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.databaseEnabled = false

        wv.webChromeClient = object : WebChromeClient() {}
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false // keep in safe view
            }
        }

        wv.loadUrl(url)
    }
}