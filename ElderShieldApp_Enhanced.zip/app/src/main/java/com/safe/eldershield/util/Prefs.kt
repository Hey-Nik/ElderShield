package com.safe.eldershield.util

import android.content.Context

object Prefs {
    private const val P = "eldershield_prefs"
    fun getSecret(ctx: Context): String =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getString("secret", "") ?: ""
    fun setSecret(ctx: Context, v: String) =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("secret", v).apply()

    fun getCaregiverNumber(ctx: Context): String =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getString("caregiver", "") ?: ""
    fun setCaregiverNumber(ctx: Context, v: String) =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("caregiver", v).apply()
}